package demo;

println "Welcome in groovy world"
