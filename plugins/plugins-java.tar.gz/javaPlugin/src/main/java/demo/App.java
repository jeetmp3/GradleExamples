package demo;

import java.util.Date;

public class App {
	public static void main(String[] args) {
		System.out.println("Current Time is : "+new Date().toString());
	}
}
