package demo;

public class App {
	public static void main(String[] args) {
		System.out.println("HELLO " );
	}
}
